# Validação da Odisseia

## Resultado

- **43 testes de integração aprovados**, executados em ambiente DOM com JavaScript real.
- **Cinco larguras verificadas em Chromium:** 320, 390, 768, 1024 e 1440 px.
- Nos percursos de navegador testados, nenhuma exceção JavaScript foi registrada e nenhuma dessas larguras apresentou transbordamento horizontal.
- Revisão visual de tela de jogo, loja, mapa, forja e encontro com guardião.
- Verificação adicional da visibilidade da carta selecionada no computador, reprodução/parada da música e jogada no layout móvel.

## Regras exercitadas

Inicialização, carta alta/par/sequência/full house e coringas, projeção sem consumir a sequência aleatória, personagens, custos e limites dos poderes, quatro especializações, Convergência, evolução de artefatos, fusões, inscrições, progressão das cartas, bloqueios por chefe, economia de pular blinds e cartas douradas, mapa e pactos, guardião opcional, ocultação de cartas, recompensa única de objetivos, saves, migração de versões anteriores, coleção, histórico, desafios e reinício após derrota.

O teste de transições percorre os **24 blinds**, alcança a tela de vitória e entra no modo infinito. Esse teste usa níveis de mão elevados para isolar a progressão; ele não demonstra que toda estratégia vence a campanha.

No navegador foram exercitados: selecionar e jogar; abrir/fechar coleção com teclado; evoluir e fundir artefatos; despertar uma carta; escolher um evento e sua decisão; continuar o mapa; revelar cartas ocultas com a Oráculo; alterar velocidade/movimento; escolher personagem e especialização em uma nova partida.

## Limites

- A validação de navegador foi realizada em Chromium. Não houve teste em um iPhone/iPad físico, Safari ou Firefox.
- As simulações exploratórias de estratégia alcançaram os últimos Antes e o chefe final, mas não constituem validação completa de dificuldade. A curva foi ajustada e há um contrato Aprendiz para experimentação. O equilíbrio entre todas as combinações continua sujeito a partidas reais.
- Os testes cobrem cenários específicos, não todas as combinações possíveis de chefes, relíquias, cartas, sementes e rotas.
- Música sintetizada foi verificada pelo funcionamento do AudioContext e pelo acionamento dos controles; não houve avaliação auditiva em dispositivos físicos.
- Saves continuam locais ao navegador, sem sincronização em nuvem.

Os testes de integração e navegador estão na pasta `tests/` e podem ser executados seguindo o `LEIA-ME.md`.
