# A Fenda: Odisseia

Expansão da versão Eclipse, construída sobre o jogo enviado. O arquivo `index.html` contém todo o jogo: HTML, CSS, JavaScript, ilustrações vetoriais, efeitos e música sintetizada. Não é necessário instalar pacotes para jogar.

## Abrir o jogo

1. Extraia o ZIP.
2. No computador, abra `index.html` em um navegador moderno.
3. Clique em **Nova run** para escolher personagem, especialização, desafio e contrato.
4. Para aprender os novos sistemas, use **Opções → Como jogar**. O contrato **Aprendiz** dá uma mão extra e reduz as metas em 25%.

No celular e no tablet, publique `index.html` em uma hospedagem estática e abra o endereço no navegador. O visualizador de arquivos do iPhone pode mostrar apenas uma prévia sem executar o jogo. O ZIP não inclui publicação nem um aplicativo nativo.

## Conteúdo desta expansão

### Personagens e Ressonância

| Personagem | Vantagem e custo |
| --- | --- |
| A Viajante | +$3 iniciais; compra um descarte por $2, uma vez por blind. |
| O Artífice | Forja $2 mais barata, mínimo $1; começa com $3 a menos. Aprimora uma carta escolhida por $3, uma vez por blind. |
| A Oráculo | +2 energia e −1 descarte por blind. Revela cartas ocultas e prepara +30 fichas por 2 energia. |
| O Errante | +5 Mult ao jogar exatamente três cartas, mas começa cada blind com uma mão a menos. Compra uma mão extra por $4. |

Cada personagem começa com uma relíquia relacionada ao seu estilo. Os poderes recarregam a cada blind.

- **Eco:** a terceira repetição consecutiva da mesma combinação recebe ×1,7.
- **Ruptura:** variar combinações fortalece o próximo Pulso, até +45 fichas adicionais.
- **Eclipse:** uma vez por blind, gaste toda a energia (mínimo 5) para escolher ×1,75 na próxima mão, +120 fichas ou uma mão extra. Cada opção cobra um custo adicional explicitado na tela.
- **Sobrecarga:** guardar 6 ou mais energia dá +5 Mult, mas guardiões reduzem o resultado em 10% nessa condição.

### Mapa e escolhas

A loja tem quatro abas: **Vitrine**, **Ateliê**, **Caminho** e **Penhor**. Escolha um caminho antes de continuar. São oferecidas três alternativas de um conjunto de oito rotas.

- Refúgio, batalha e mercado conservam os benefícios e riscos das rotas anteriores.
- Tesouro entrega dinheiro e energia com uma meta maior.
- Forja Errante desperta uma habilidade em uma carta escolhida.
- Encruzilhada permite receber um artefato com maldição persistente, sacrificar o primeiro artefato do inventário por recompensa ou passar em segurança.
- Guardião Opcional adiciona regras de chefe ao próximo blind. Vencer dá $7 e um nível na última combinação. Ele não substitui o terceiro blind obrigatório de cada Ante.

### Relíquias e cartas que evoluem

Artefatos ganham progresso quando seus efeitos são ativados. Depois de seis ativações, escolha uma evolução gratuita na loja: +35 fichas ou +4 Mult. Os artefatos utilitários progridem ao gerar seu benefício.

Quatro receitas de fusão custam $4 e consomem seus dois ingredientes, inclusive edições e evoluções:

| Ingredientes | Resultado |
| --- | --- |
| Lua de Papel + Tinta Violeta | Sol Engarrafado |
| Régua Torta + Espelho Macio | Horizonte Partido |
| Coração de Âmbar + Bigorna Estelar | Motor de Estrelas |
| Prisma da Aurora + Bússola Impossível | Coroa do Vazio |

A inscrição de cartas compartilha a ação da forja de aprimoramentos. Cada carta pode receber uma habilidade:

- **Dínamo:** gera energia ao pontuar.
- **Prisma:** ganha Mult por outras cartas pontuadas do mesmo naipe.
- **Semente:** acumula fichas conforme é usada.

Após pontuar três vezes, a habilidade se fortalece. Aprimoramentos, selos e habilidades coexistem.

### Apresentação e conforto

- Mesa astral com constelações vetoriais e ambientes que mudam a cada Ante.
- Retratos vetoriais de guardiões, falas, dicas e aviso da Fase II.
- Arte vetorial para relíquias, contagem de pontos em etapas e partículas.
- Música ambiente sintetizada que muda durante chefes e perto da meta.
- Velocidade de pontuação em 0,5×, 1×, 2× ou 4×; opção para reduzir movimento.
- Cartas em grade no celular, HUD compacto, comandos reorganizados e painéis secundários recolhíveis.
- Coleção de artefatos, combinações e chefes; histórico local de até 30 partidas concluídas, perdidas ou abandonadas.
- Três desafios adicionais: Silêncio Astral, Última Luz e Bolso Vazio.

### Correções e equilíbrio

- Pular um blind não concede prêmio de vitória nem juros e não é permitido depois da primeira mão.
- Cartas douradas rendem dinheiro somente se estiverem na mão ao vencer o blind.
- O selo violeta gera frascos no descarte, não ao jogar a carta.
- A projeção não revela cartas ocultas pelo Peixe Cego; a Oráculo pode revelá-las.
- A ordem de seleção é respeitada pelo Crupiê sem Rosto.
- Nova run fecha os diálogos anteriores e limpa os efeitos de pontuação.
- Venda e fusão removem corretamente edições e evoluções dos ingredientes.
- O crescimento das metas da campanha foi reduzido de 100× para 65× entre o primeiro e o oitavo Ante; o modo infinito continua crescendo.
- O contrato Aprendiz oferece uma alternativa mais acessível sem alterar a Travessia padrão.

## Saves e compatibilidade

O jogo continua usando a chave de save da versão anterior e adiciona valores padrão para os novos sistemas. A coleção possui uma chave separada. Personagem e especialização novos são escolhidos em Nova run; uma partida anterior carregada recebe os padrões compatíveis.

O save depende do navegador e do endereço do jogo. Mover o arquivo, trocar a hospedagem, limpar os dados do site ou usar outro navegador pode fazer a partida anterior deixar de aparecer. Não há sincronização em nuvem.

## Controles

- Clique/toque: selecionar até cinco cartas.
- Enter: jogar a seleção.
- Backspace: descartar a seleção.
- 1–9 e 0: selecionar por posição.
- Esc: fechar os diálogos de consulta/configuração.
- Tab/Shift+Tab: navegar pelos controles do diálogo aberto.

## Testes para desenvolvimento

Os pacotes abaixo são opcionais e servem somente para testes. O jogo não depende deles para funcionar.

```sh
npm install
npm test
npx playwright install chromium
npm run test:browser
```

`npm test` verifica regras, custos, saves, fusões, evolução, desafios e transições da campanha. `npm run test:browser` verifica interações em cinco larguras e grava capturas em `tests/results/`. É possível usar um Chromium já instalado definindo `FENDA_CHROMIUM` com o caminho do executável.

Consulte `VALIDACAO.md` para o alcance e as limitações dos testes realizados.
