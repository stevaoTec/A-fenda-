const {chromium}=require('playwright');const fs=require('fs'),assert=require('assert/strict');const fixtures=require('./fixtures.cjs');const path=require('path'),{pathToFileURL}=require('url');const target=pathToFileURL(path.join(__dirname,'../index.html')).href;const screenshotDir=path.join(__dirname,'results');fs.mkdirSync(screenshotDir,{recursive:true});
(async()=>{const b=await chromium.launch({headless:true,...(process.env.FENDA_CHROMIUM?{executablePath:process.env.FENDA_CHROMIUM}:{}),args:['--no-sandbox','--disable-dev-shm-usage']});const errors=[];const report=[];
const p=await b.newPage({viewport:{width:390,height:900}});p.on('pageerror',e=>errors.push(e.message));
for(const width of [320,390,768,1024,1440]){
 await p.setViewportSize({width,height:900});
 await p.goto(target);await p.evaluate(save=>window.addEventListener('pagehide',()=>localStorage.setItem('a-fenda-save-v1',save),{once:true}),fixtures.play);await p.reload();await p.waitForTimeout(500);
 assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth),width);
 await p.locator('#hand-cards .card').first().click();const pre=await p.evaluate(()=>JSON.parse(localStorage.getItem('a-fenda-save-v1')).state.runHands);
 await p.locator('#archive-button').click();await p.locator('[data-archive="bosses"]').click();await p.locator('#archive-close').press('Enter');await p.waitForTimeout(50);assert.equal(await p.evaluate(()=>JSON.parse(localStorage.getItem('a-fenda-save-v1')).state.runHands),pre);
 await p.locator('#play-button').click();assert.equal(await p.evaluate(()=>JSON.parse(localStorage.getItem('a-fenda-save-v1')).state.runHands),pre+1);
 if(width===390||width===1440)await p.screenshot({path:path.join(screenshotDir,`play-${width}.png`),fullPage:false});
 await p.evaluate(save=>window.addEventListener('pagehide',()=>localStorage.setItem('a-fenda-save-v1',save),{once:true}),fixtures.shop);await p.reload();await p.waitForTimeout(300);
 await p.locator('[data-shop-tab="forge"]').click();await p.getByRole('button',{name:'Encantar · +4 Mult',exact:true}).click();await p.getByRole('button',{name:'Fundir · $4',exact:true}).first().click();
 assert.ok(await p.evaluate(()=>JSON.parse(localStorage.getItem('a-fenda-save-v1')).state.artifacts.includes('fusion-sun')));
 await p.locator('#awaken-card').selectOption({index:1});await p.getByRole('button',{name:'Dínamo',exact:true}).click();
 if(width===390)await p.screenshot({path:path.join(screenshotDir,'forge-mobile.png'),fullPage:false});
 await p.locator('[data-shop-tab="route"]').click();await p.getByRole('button',{name:/Encruzilhada/}).click();assert.ok(await p.locator('#continue-button').isDisabled());await p.getByRole('button',{name:/Passar em silêncio/}).click();assert.ok(await p.locator('#continue-button').isEnabled());
 assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth),width);
 if(width===390||width===1440)await p.screenshot({path:path.join(screenshotDir,`map-${width}.png`),fullPage:false});
 await p.locator('#continue-button').click();assert.equal(await p.evaluate(()=>JSON.parse(localStorage.getItem('a-fenda-save-v1')).state.blind),1);
 await p.evaluate(save=>window.addEventListener('pagehide',()=>localStorage.setItem('a-fenda-save-v1',save),{once:true}),fixtures.boss);await p.reload();await p.waitForTimeout(300);assert.ok(await p.locator('#guardian-panel').isVisible());await p.locator('#hand-cards .card').first().click();assert.ok((await p.locator('#hand-preview').textContent()).includes('bloqueada'));await p.locator('#hero-strip button').click();assert.ok(!(await p.locator('#hand-preview').textContent()).includes('bloqueada'));
 if(width===390||width===1440)await p.screenshot({path:path.join(screenshotDir,`boss-${width}.png`),fullPage:false});
 await p.locator('#options-button').click();await p.locator('#speed-option').selectOption('4');await p.locator('#reduced-option').check();await p.locator('#options-close').click();assert.equal(await p.locator('html').getAttribute('data-reduced'),'true');
 await p.locator('#new-run-button').click();await p.locator('#hero-choices button').nth(1).click();await p.locator('#discipline-choices button').nth(2).click();await p.locator('#seed-input').fill('UI-NEW');await p.locator('#confirm-new').click();assert.equal(await p.evaluate(()=>JSON.parse(localStorage.getItem('a-fenda-save-v1')).state.character),'smith');
 report.push({width,passed:true});console.log("PASS viewport "+width);
}
assert.deepEqual(errors,[]);console.log(JSON.stringify({report,errors},null,2));await b.close();})();
